const express = require('express');
const bodyParser = require('body-parser');
const swaggerUi = require('swagger-ui-express');
const usuarioRoutes = require('./routes/usuarioRoutes');
const categoriaRoutes = require('./routes/categoriaRoutes');
const receitaRoutes = require('./routes/receitaRoutes');
const despesaRoutes = require('./routes/despesaRoutes');
const metaRoutes = require('./routes/metaRoutes');
const swaggerDocument = require('./swagger/swagger.json');

require('dotenv').config();

const app = express();
app.use(bodyParser.json());

// Rotas
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use('/usuarios', usuarioRoutes);

// const categoriaRoutes = require('./routes/categoriaRoutes');
app.use('/categorias', categoriaRoutes);
app.use('/receitas', receitaRoutes);
app.use('/despesas', despesaRoutes);
app.use('/metas', metaRoutes);

// Inicializar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
