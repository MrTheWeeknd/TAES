const express = require('express');
const router = express.Router();
const metaController = require('../controllers/metaController');

// Rotas
router.get('/', metaController.getAllMetas);
router.get('/:id', metaController.getMetaById);
router.post('/', metaController.createMeta);
router.put('/:id', metaController.updateMeta);
router.delete('/:id', metaController.deleteMeta);

module.exports = router;
