const express = require('express');
const router = express.Router();
const relatorioController = require('../controllers/relatorioController');

// Rota para obter todos os relatórios
router.get('/', relatorioController.getAllRelatorios);

// Rota para criar um novo relatório
router.post('/', relatorioController.createRelatorio);

module.exports = router;
