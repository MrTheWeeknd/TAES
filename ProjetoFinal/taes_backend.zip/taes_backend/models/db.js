const mysql = require('mysql2');
require('dotenv').config(); // Carregar as variáveis do .env

const pool = mysql.createPool({
  host: process.env.DB_HOST,        // Endereço do host do banco de dados
  user: process.env.DB_USER,        // Usuário do banco de dados
  password: process.env.DB_PASSWORD, // Senha do banco de dados
  database: process.env.DB_NAME,    // Nome do banco de dados
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Exportar para uso nas queries
module.exports = pool.promise();
