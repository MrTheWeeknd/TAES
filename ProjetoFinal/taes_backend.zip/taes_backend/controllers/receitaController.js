const db = require('../models/db');

// Obter todas as receitas
exports.getAllReceitas = async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM Receita');
        res.status(200).json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Obter receita por ID
exports.getReceitaById = async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await db.execute('SELECT * FROM Receita WHERE ID = ?', [id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Receita não encontrada' });
        res.status(200).json(rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Criar nova receita
exports.createReceita = async (req, res) => {
    const { Usuario_ID, Valor, Descricao, Data, Categoria_ID } = req.body;

    // Converte a data para o formato esperado pelo MySQL
    const formattedData = new Date(Data).toISOString().slice(0, 19).replace('T', ' ');

    try {
        const query = `
        INSERT INTO Receita (Usuario_ID, Valor, Descricao, Data, Categoria_ID) 
        VALUES (?, ?, ?, ?, ?)
      `;
        const [result] = await db.execute(query, [Usuario_ID, Valor, Descricao, formattedData, Categoria_ID]);
        res.status(201).json({ id: result.insertId, Usuario_ID, Valor, Descricao, Data: formattedData, Categoria_ID });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


// Atualizar receita
exports.updateReceita = async (req, res) => {
    const { id } = req.params;
    const { Usuario_ID, Valor, Descricao, Data, Categoria_ID } = req.body;

    // Converte a data para o formato esperado pelo MySQL
    const formattedData = Data ? new Date(Data).toISOString().slice(0, 19).replace('T', ' ') : null;

    try {
        const query = `
        UPDATE Receita 
        SET Usuario_ID = ?, Valor = ?, Descricao = ?, Data = ?, Categoria_ID = ?
        WHERE ID = ?
      `;
        const [result] = await db.execute(query, [Usuario_ID, Valor, Descricao, formattedData, Categoria_ID, id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Receita não encontrada" });
        }

        res.status(200).json({ message: "Receita atualizada com sucesso" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


// Excluir receita por ID
exports.deleteReceita = async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await db.execute('DELETE FROM Receita WHERE ID = ?', [id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Receita não encontrada' });
        res.status(200).json({ message: 'Receita excluída com sucesso' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
