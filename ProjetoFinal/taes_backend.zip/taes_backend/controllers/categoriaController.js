const db = require('../models/db');

// Obter todas as categorias
exports.getAllCategories = async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM Categoria');
    res.status(200).json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obter uma categoria por ID
exports.getCategoryById = async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await db.execute('SELECT * FROM Categoria WHERE ID = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Categoria não encontrada' });
    }
    res.status(200).json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Criar uma nova categoria
exports.createCategory = async (req, res) => {
  const { Nome, Tipo, Usuario_ID } = req.body;
  try {
    const [result] = await db.execute(
      'INSERT INTO Categoria (Nome, Tipo, Usuario_ID) VALUES (?, ?, ?)',
      [Nome, Tipo, Usuario_ID]
    );
    res.status(201).json({ message: 'Categoria criada com sucesso', id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Atualizar uma categoria existente
exports.updateCategory = async (req, res) => {
  const { id } = req.params;
  const { Nome, Tipo, Usuario_ID } = req.body;
  try {
    const [result] = await db.execute(
      'UPDATE Categoria SET Nome = ?, Tipo = ?, Usuario_ID = ? WHERE ID = ?',
      [Nome, Tipo, Usuario_ID, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Categoria não encontrada' });
    }
    res.status(200).json({ message: 'Categoria atualizada com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Deletar uma categoria
exports.deleteCategory = async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await db.execute('DELETE FROM Categoria WHERE ID = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Categoria não encontrada' });
    }
    res.status(200).json({ message: 'Categoria deletada com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
