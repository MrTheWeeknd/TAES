const db = require('../models/db'); // Supondo que a conexão com o banco seja via db.js

// Função para obter todos os relatórios
exports.getAllRelatorios = async (req, res) => {
  try {
    const [relatorios] = await db.query('SELECT * FROM Relatorio');
    res.status(200).json(relatorios);
  } catch (err) {
    console.error('Erro ao obter relatórios:', err);
    res.status(500).json({ error: 'Erro ao obter relatórios' });
  }
};

// Função para criar um novo relatório
exports.createRelatorio = async (req, res) => {
  const { Usuario_ID, Descricao, DataInicio, DataFim, TotalReceitas, TotalDespesas, Saldo } = req.body;

  // Verificar se as datas são válidas
  const isValidDate = (date) => !isNaN(Date.parse(date));
  if (!isValidDate(DataInicio) || !isValidDate(DataFim)) {
    return res.status(400).json({ error: 'Data inválida fornecida. As datas devem estar no formato YYYY-MM-DD.' });
  }

  // Formatar as datas
  const dataInicioFormatada = new Date(DataInicio).toISOString().split('T')[0];
  const dataFimFormatada = new Date(DataFim).toISOString().split('T')[0];

  try {
    const query = `
      INSERT INTO Relatorio (Usuario_ID, Descricao, DataInicio, DataFim, TotalReceitas, TotalDespesas, Saldo)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [Usuario_ID, Descricao, dataInicioFormatada, dataFimFormatada, TotalReceitas, TotalDespesas, Saldo];

    const [result] = await db.query(query, values);

    res.status(201).json({
      message: 'Relatório criado com sucesso!',
      relatorio: {
        ID: result.insertId,
        Usuario_ID,
        Descricao,
        DataInicio: dataInicioFormatada,
        DataFim: dataFimFormatada,
        TotalReceitas,
        TotalDespesas,
        Saldo
      }
    });
  } catch (err) {
    console.error('Erro ao criar relatório:', err);
    res.status(500).json({ error: 'Erro ao criar relatório' });
  }
};
