const db = require('../models/db');

// Obter todos os usuários
exports.getAllUsers = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM Usuario');
    res.status(200).json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obter usuário por ID
exports.getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await db.query('SELECT * FROM Usuario WHERE ID = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Usuário não encontrado' });
    }
    res.status(200).json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Criar novo usuário
exports.createUser = async (req, res) => {
  try {
    const { Nome, Email, Senha, DataNascimento, Genero, Telefone } = req.body;
    const [result] = await db.query(
      'INSERT INTO Usuario (Nome, Email, Senha, DataNascimento, Genero, Telefone) VALUES (?, ?, ?, ?, ?, ?)',
      [Nome, Email, Senha, DataNascimento, Genero, Telefone]
    );
    res.status(201).json({ message: 'Usuário criado com sucesso', id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Atualizar usuário por ID
exports.updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { Nome, Email, Senha, DataNascimento, Genero, Telefone } = req.body;
    const [result] = await db.query(
      'UPDATE Usuario SET Nome = ?, Email = ?, Senha = ?, DataNascimento = ?, Genero = ?, Telefone = ? WHERE ID = ?',
      [Nome, Email, Senha, DataNascimento, Genero, Telefone, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Usuário não encontrado' });
    }
    res.status(200).json({ message: 'Usuário atualizado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Excluir usuário por ID
exports.deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await db.query('DELETE FROM Usuario WHERE ID = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Usuário não encontrado' });
    }
    res.status(200).json({ message: 'Usuário excluído com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
