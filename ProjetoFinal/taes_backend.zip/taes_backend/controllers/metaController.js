const db = require('../models/db');

// Criar uma nova meta
exports.createMeta = async (req, res) => {
    const { Usuario_ID, Descricao, ValorAlvo, DataInicio, DataTermino } = req.body;

    // Converter as datas para o formato 'YYYY-MM-DD'
    const dataInicioFormatada = new Date(DataInicio).toISOString().split('T')[0]; // 'YYYY-MM-DD'
    const dataTerminoFormatada = new Date(DataTermino).toISOString().split('T')[0]; // 'YYYY-MM-DD'

    try {
        const query = `
      INSERT INTO Meta (Usuario_ID, Descricao, ValorAlvo, DataInicio, DataTermino)
      VALUES (?, ?, ?, ?, ?)
    `;
        const values = [Usuario_ID, Descricao, ValorAlvo, dataInicioFormatada, dataTerminoFormatada];

        const [result] = await db.query(query, values);

        res.status(201).json({
            message: 'Meta criada com sucesso!',
            meta: {
                ID: result.insertId,
                Usuario_ID,
                Descricao,
                ValorAlvo,
                DataInicio: dataInicioFormatada,
                DataTermino: dataTerminoFormatada
            }
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao criar meta' });
    }
};


// Obter todas as metas
exports.getAllMetas = async (req, res) => {
    try {
        const [metas] = await db.query('SELECT * FROM Meta');
        res.status(200).json(metas);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao obter metas' });
    }
};

// Obter uma meta específica
exports.getMetaById = async (req, res) => {
    const { id } = req.params;

    try {
        const [meta] = await db.query('SELECT * FROM Meta WHERE ID = ?', [id]);

        if (meta.length === 0) {
            return res.status(404).json({ error: 'Meta não encontrada' });
        }

        res.status(200).json(meta[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao obter meta' });
    }
};

// Atualizar uma meta
exports.updateMeta = async (req, res) => {
    const { ID } = req.params;
    const { Usuario_ID, Descricao, ValorAlvo, DataInicio, DataTermino } = req.body;

    // Verificar se as datas são válidas
    const isValidDate = (date) => !isNaN(Date.parse(date));

    // Verificar se DataInicio e DataTermino são válidas
    if (!isValidDate(DataInicio) || !isValidDate(DataTermino)) {
        return res.status(400).json({ error: 'Data inválida fornecida. As datas devem estar no formato YYYY-MM-DD.' });
    }

    // Converter as datas para o formato 'YYYY-MM-DD'
    const dataInicioFormatada = new Date(DataInicio).toISOString().split('T')[0]; // 'YYYY-MM-DD'
    const dataTerminoFormatada = new Date(DataTermino).toISOString().split('T')[0]; // 'YYYY-MM-DD'

    try {
        const query = `
        UPDATE Meta
        SET Usuario_ID = ?, Descricao = ?, ValorAlvo = ?, DataInicio = ?, DataTermino = ?
        WHERE ID = ?
      `;
        const values = [Usuario_ID, Descricao, ValorAlvo, dataInicioFormatada, dataTerminoFormatada, ID];

        const [result] = await db.query(query, values);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Meta não encontrada' });
        }

        res.status(200).json({
            message: 'Meta atualizada com sucesso!',
            meta: {
                ID,
                Usuario_ID,
                Descricao,
                ValorAlvo,
                DataInicio: dataInicioFormatada,
                DataTermino: dataTerminoFormatada
            }
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao atualizar meta' });
    }
};

// Deletar uma meta
exports.deleteMeta = async (req, res) => {
    const { id } = req.params;

    try {
        const [result] = await db.query('DELETE FROM Meta WHERE ID = ?', [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Meta não encontrada para deletar' });
        }

        res.status(200).json({ message: 'Meta deletada com sucesso!' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao deletar meta' });
    }
};
