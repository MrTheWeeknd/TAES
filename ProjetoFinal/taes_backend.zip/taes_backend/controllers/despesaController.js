const db = require('../models/db');

// Obter todas as despesas
exports.getAllDespesas = async (req, res) => {
  try {
    const [result] = await db.execute('SELECT * FROM Despesa');
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obter despesa por ID
exports.getDespesaById = async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await db.execute('SELECT * FROM Despesa WHERE ID = ?', [id]);
    if (result.length === 0) {
      return res.status(404).json({ error: 'Despesa não encontrada' });
    }
    res.status(200).json(result[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Criar nova despesa
exports.createDespesa = async (req, res) => {
  const { Usuario_ID, Valor, Descricao, Data, Categoria_ID } = req.body;

  // Formatar a data para o padrão MySQL
  const formattedData = Data ? new Date(Data).toISOString().slice(0, 19).replace('T', ' ') : null;

  try {
    const query = `
      INSERT INTO Despesa (Usuario_ID, Valor, Descricao, Data, Categoria_ID)
      VALUES (?, ?, ?, ?, ?)
    `;
    const [result] = await db.execute(query, [Usuario_ID, Valor, Descricao, formattedData, Categoria_ID]);
    res.status(201).json({ message: 'Despesa criada com sucesso', id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Atualizar despesa
exports.updateDespesa = async (req, res) => {
  const { id } = req.params;
  const { Usuario_ID, Valor, Descricao, Data, Categoria_ID } = req.body;

  // Formatar a data para o padrão MySQL
  const formattedData = Data ? new Date(Data).toISOString().slice(0, 19).replace('T', ' ') : null;

  try {
    const query = `
      UPDATE Despesa
      SET Usuario_ID = ?, Valor = ?, Descricao = ?, Data = ?, Categoria_ID = ?
      WHERE ID = ?
    `;
    const [result] = await db.execute(query, [Usuario_ID, Valor, Descricao, formattedData, Categoria_ID, id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Despesa não encontrada' });
    }
    res.status(200).json({ message: 'Despesa atualizada com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Excluir despesa
exports.deleteDespesa = async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await db.execute('DELETE FROM Despesa WHERE ID = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Despesa não encontrada' });
    }
    res.status(200).json({ message: 'Despesa excluída com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
