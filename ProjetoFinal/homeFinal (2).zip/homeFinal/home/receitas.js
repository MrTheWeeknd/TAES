// Função para gerar um ID único
function gerarIdUnico() {
  return `id-${Date.now()}-${Math.random().toString(16).substr(2, 8)}`;
}

// Função para carregar receitas do Local Storage
function carregarReceitas() {
  const receitas = JSON.parse(localStorage.getItem("receitas")) || [];
  const listaReceitas = document.getElementById("receitas-list");
  listaReceitas.innerHTML = ""; // Limpar lista antes de recarregar

  receitas.forEach((receita) => {
    const receitaItem = document.createElement("li");
    receitaItem.classList.add(
      "list-group-item",
      "d-flex",
      "justify-content-between",
      "align-items-center"
    );
    receitaItem.setAttribute("data-id", receita.id); // Associar ID ao item
    receitaItem.innerHTML = `${receita.descricao} - R$ ${receita.valor}
            <span>
                <button class="btn btn-sm btn-warning" onclick="editReceita(this)">Editar</button>
                <button class="btn btn-sm btn-danger" onclick="deleteReceita(this)">Excluir</button>
            </span>`;
    listaReceitas.appendChild(receitaItem);
  });
}

// Salvar receitas no Local Storage
function salvarReceita(descricao, valor) {
  const receitas = JSON.parse(localStorage.getItem("receitas")) || [];
  const novaReceita = { id: gerarIdUnico(), descricao, valor };
  receitas.push(novaReceita);
  localStorage.setItem("receitas", JSON.stringify(receitas));
}

// Atualizar receitas no Local Storage
function atualizarReceita(id, novaDescricao, novoValor) {
  const receitas = JSON.parse(localStorage.getItem("receitas")) || [];
  const index = receitas.findIndex((r) => r.id === id);
  if (index !== -1) {
    receitas[index].descricao = novaDescricao;
    receitas[index].valor = novoValor;
    localStorage.setItem("receitas", JSON.stringify(receitas));
  }
}

// Remover receitas do Local Storage
function removerReceita(id) {
  const receitas = JSON.parse(localStorage.getItem("receitas")) || [];
  const novasReceitas = receitas.filter((r) => r.id !== id);
  localStorage.setItem("receitas", JSON.stringify(novasReceitas));
}

// Adicionar evento ao formulário
document
  .getElementById("add-receita-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    const descricao = document.getElementById("descricao-receita").value;
    const valor = document.getElementById("valor-receita").value;

    if (descricao && valor) {
      // Salvar no Local Storage
      salvarReceita(descricao, valor);

      // Recarregar a lista
      carregarReceitas();

      // Limpar os campos
      document.getElementById("descricao-receita").value = "";
      document.getElementById("valor-receita").value = "";

      alert("Receita adicionada com sucesso!");
    }
  });

// Função para editar uma receita
function editReceita(button) {
  const li = button.parentElement.parentElement;
  const id = li.getAttribute("data-id"); // Recuperar ID do item
  const receitas = JSON.parse(localStorage.getItem("receitas")) || [];
  const receita = receitas.find((r) => r.id === id);

  if (receita) {
    const novaDescricao = prompt(
      "Edite a descrição da receita:",
      receita.descricao
    );
    const novoValor = prompt("Edite o valor da receita:", receita.valor);

    if (novaDescricao && novoValor) {
      atualizarReceita(id, novaDescricao, novoValor);
      carregarReceitas(); // Atualizar interface
      alert("Receita editada com sucesso!");
    }
  } else {
    alert("Erro: Receita não encontrada.");
  }
}

// Função para excluir uma receita
function deleteReceita(button) {
  if (confirm("Tem certeza que deseja excluir esta receita?")) {
    const li = button.parentElement.parentElement;
    const id = li.getAttribute("data-id"); // Recuperar ID do item
    removerReceita(id);
    carregarReceitas(); // Atualizar interface
    alert("Receita excluída com sucesso!");
  }
}

// Carregar receitas ao iniciar a página
document.addEventListener("DOMContentLoaded", carregarReceitas);
