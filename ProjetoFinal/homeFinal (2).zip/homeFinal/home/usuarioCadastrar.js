async function cadastrarUsuario(nome, email, senha) {
  try {
    const response = await fetch("http://localhost:3000/usuarios", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nome, email, senha }),
    });
    const data = await response.json();
    console.log("Usuário cadastrado:", data);
  } catch (error) {
    console.error("Erro ao cadastrar usuário:", error);
  }
}
