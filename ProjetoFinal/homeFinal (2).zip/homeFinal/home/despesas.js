// Função para gerar um ID único
function gerarIdUnico() {
  return `id-${Date.now()}-${Math.random().toString(16).substr(2, 8)}`;
}

// Função para carregar despesas do Local Storage
function carregarDespesas() {
  const despesas = JSON.parse(localStorage.getItem("despesas")) || [];
  const listaDespesas = document.getElementById("despesas-list");
  listaDespesas.innerHTML = ""; // Limpar lista antes de recarregar

  despesas.forEach((despesa) => {
    const despesaItem = document.createElement("li");
    despesaItem.classList.add(
      "list-group-item",
      "d-flex",
      "justify-content-between",
      "align-items-center"
    );
    despesaItem.setAttribute("data-id", despesa.id); // Associar ID ao item
    despesaItem.innerHTML = `${despesa.descricao} - R$ ${despesa.valor}
            <span>
                <button class="btn btn-sm btn-warning" onclick="editDespesa(this)">Editar</button>
                <button class="btn btn-sm btn-danger" onclick="deleteDespesa(this)">Excluir</button>
            </span>`;
    listaDespesas.appendChild(despesaItem);
  });
}

// Salvar despesas no Local Storage
function salvarDespesa(descricao, valor) {
  const despesas = JSON.parse(localStorage.getItem("despesas")) || [];
  const novaDespesa = { id: gerarIdUnico(), descricao, valor };
  despesas.push(novaDespesa);
  localStorage.setItem("despesas", JSON.stringify(despesas));
}

// Atualizar despesas no Local Storage
function atualizarDespesa(id, novaDescricao, novoValor) {
  const despesas = JSON.parse(localStorage.getItem("despesas")) || [];
  const index = despesas.findIndex((d) => d.id === id);
  if (index !== -1) {
    despesas[index].descricao = novaDescricao;
    despesas[index].valor = novoValor;
    localStorage.setItem("despesas", JSON.stringify(despesas));
  }
}

// Remover despesas do Local Storage
function removerDespesa(id) {
  const despesas = JSON.parse(localStorage.getItem("despesas")) || [];
  const novasDespesas = despesas.filter((d) => d.id !== id);
  localStorage.setItem("despesas", JSON.stringify(novasDespesas));
}

// Adicionar evento ao formulário
document
  .getElementById("add-despesa-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    const descricao = document.getElementById("descricao").value;
    const valor = document.getElementById("valor").value;

    if (descricao && valor) {
      // Salvar no Local Storage
      salvarDespesa(descricao, valor);

      // Recarregar a lista
      carregarDespesas();

      // Limpar os campos
      document.getElementById("descricao").value = "";
      document.getElementById("valor").value = "";

      alert("Despesa adicionada com sucesso!");
    }
  });

// Função para editar uma despesa
function editDespesa(button) {
  const li = button.parentElement.parentElement;
  const id = li.getAttribute("data-id"); // Recuperar ID do item
  const despesas = JSON.parse(localStorage.getItem("despesas")) || [];
  const despesa = despesas.find((d) => d.id === id);

  if (despesa) {
    const novaDescricao = prompt(
      "Edite a descrição da despesa:",
      despesa.descricao
    );
    const novoValor = prompt("Edite o valor da despesa:", despesa.valor);

    if (novaDescricao && novoValor) {
      atualizarDespesa(id, novaDescricao, novoValor);
      carregarDespesas(); // Atualizar interface
      alert("Despesa editada com sucesso!");
    }
  } else {
    alert("Erro: Despesa não encontrada.");
  }
}

// Função para excluir uma despesa
function deleteDespesa(button) {
  if (confirm("Tem certeza que deseja excluir esta despesa?")) {
    const li = button.parentElement.parentElement;
    const id = li.getAttribute("data-id"); // Recuperar ID do item
    removerDespesa(id);
    carregarDespesas(); // Atualizar interface
    alert("Despesa excluída com sucesso!");
  }
}

// Carregar despesas ao iniciar a página
document.addEventListener("DOMContentLoaded", carregarDespesas);
