async function listarReceitas() {
  try {
    const response = await fetch("http://localhost:3000/receitas");
    const receitas = await response.json();
    console.log("Receitas:", receitas);
    // Atualizar o DOM com os dados
  } catch (error) {
    console.error("Erro ao listar receitas:", error);
  }
}
